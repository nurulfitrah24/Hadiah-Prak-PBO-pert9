/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hadiah1;

/**
 *
 * @author ADAM
 */
import javax.swing.*;
import java.awt.event.*;

public abstract class Hadiah1 implements ActionListener {

    private static void createAndShowGUI(){
        JFrame frame = new JFrame("Program Berkurang");
        //buat frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20, 30, 300, 150);
        frame.getContentPane().setLayout(null);
        
        //Buat tombol
        JButton butt= new JButton("Klik Disini");
        frame.getContentPane().add(butt);
        butt.setBounds(20, 30, 200, 20);
        
        //membuat instance objek aplikasi   
        Hadiah1 app = new Hadiah1() {};
            //make the label
         app.label = new JLabel("clicks = 3");
         app.label.setBounds(20, 50, 200,30);
         frame.getContentPane().add(app.label);
         
         butt.addActionListener(app);
         frame.setVisible(true);          
            
    }
        public void actionPerformed(ActionEvent e) {
             
             clickCount-=1;
             label.setText("clicks = "+clickCount);  
            }
    public static void main(String[] args) {
        // TODO code application logic here
         SwingUtilities.invokeLater(new Runnable (){
                public void run(){
                    createAndShowGUI();
                }
        });
    }
    
    int clickCount= 3;
    JLabel label;
}